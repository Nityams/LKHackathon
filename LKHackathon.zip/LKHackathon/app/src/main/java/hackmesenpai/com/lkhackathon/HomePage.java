package hackmesenpai.com.lkhackathon;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        TextView text = (TextView)findViewById(R.id.user_name);
        text.setTextColor(Color.RED);
        text.setTextSize(12);
        text.setText("Android Bot");

    }
}
